#include "iir.h"

absorp iirTest(char *filename)
{
	absorp myAbsorp;

	return myAbsorp;
}
