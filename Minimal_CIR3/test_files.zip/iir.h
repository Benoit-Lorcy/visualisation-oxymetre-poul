#include "define.h"


absorp iirTest(char* filename);