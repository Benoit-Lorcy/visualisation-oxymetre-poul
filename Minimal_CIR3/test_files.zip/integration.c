void integrationTest(char* filename)
{

}