#include "fir.h"

absorp firTest(char* filename){
	absorp	myAbsorp;
	
	
	return myAbsorp;
}